import React from 'react';

export default function ErrorPage(props) {
    return (
        <div>
            <h1>ErrorPage</h1>
        </div>
    );
}
