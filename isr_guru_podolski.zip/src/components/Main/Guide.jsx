import React from 'react';
import stylesTitle from '..//..//componentStyles/TitleStyle.css';

export default function Guide(props) {
    return <div>Guide</div>;
}
