export const CHANGE_EVENTS_LIST = 'CHANGE_EVENTS_LIST';

export const changeEventList = (/* change */) => ({
    type: CHANGE_EVENTS_LIST,
    // payload: change,
});
