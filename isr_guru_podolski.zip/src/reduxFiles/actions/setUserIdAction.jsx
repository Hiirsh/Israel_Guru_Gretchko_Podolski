export const USER_ID = 'USER_ID';
export const setUserIdAction = userId => ({
    type: USER_ID,
    payload: userId,
});
