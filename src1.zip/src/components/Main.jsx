import React from 'react';
import styles from '..//components/Main.css';

export default function Main() {
  return (
    <div className="main">Main</div>
  )
}
